import 'dart:convert';
import 'package:api/constans/string.dart';
import 'package:api/models/classbooks.dart';
import 'package:http/http.dart' as http;

class APIManager {
  // this method use to get data from API
  Future<Books> getData() async {
    var client = http.Client();
    var newsbook;
    try {
      var response = await client.get(Strings.newsUrl);
      if (response.statusCode == 200) {
        var jsonData = response.body;
        var jsonMap = json.decode(jsonData);

        newsbook = Books.fromJson(jsonMap);
      }
    } catch (Exception) {
      return newsbook;
    }
    return newsbook;
  }
}
