// // To parse this JSON data, do
// //
// // final books = booksFromJson(jsonString);

import 'dart:convert';

Books booksFromJson(String str) => Books.fromJson(json.decode(str));

String booksToJson(Books data) => json.encode(data.toJson());

class Books {
  Books({
    this.size,
    this.totalElements,
    this.content,
    this.page,
    this.totalPages,
  });

  int? size;
  int? totalElements;
  List<Content>? content;
  int? page;
  int? totalPages;

  factory Books.fromJson(Map<String, dynamic> json) => Books(
        size: json["size"],
        totalElements: json["totalElements"],
        content:
            List<Content>.from(json["content"].map((x) => Content.fromJson(x))),
        page: json["page"],
        totalPages: json["totalPages"],
      );

  Map<String, dynamic> toJson() => {
        "size": size,
        "totalElements": totalElements,
        "content": List<dynamic>.from(content!.map((x) => x.toJson())),
        "page": page,
        "totalPages": totalPages,
      };
}

class Content {
  Content({
    this.id,
    this.title,
    this.author,
    this.realYears,
    this.year,
    this.country,
    this.language,
    this.pages,
    this.wikipediaLink,
    this.imageUrl,
  });

  int? id;
  String? title;
  String? author;
  String? realYears;
  String? year;
  String? country;
  String? language;
  int? pages;
  String? wikipediaLink;
  String? imageUrl;

  factory Content.fromJson(Map<String, dynamic> json) => Content(
        id: json["id"],
        title: json["title"],
        author: json["author"],
        realYears: json["realYears"],
        year: json["year"],
        country: json["country"],
        language: json["language"],
        pages: json["pages"],
        wikipediaLink: json["wikipediaLink"],
        imageUrl: json["imageUrl"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "author": author,
        "realYears": realYears,
        "year": year,
        "country": country,
        "language": language,
        "pages": pages,
        "wikipediaLink": wikipediaLink,
        "imageUrl": imageUrl,
      };
}
// To parse this JSON data, do
//
//     final books = booksFromJson(jsonString);

