import 'package:flutter/material.dart';

class DetialItem extends StatefulWidget {
  const DetialItem({Key? key}) : super(key: key);
  @override
  _DetialItemState createState() => _DetialItemState();
}

class _DetialItemState extends State<DetialItem> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Item'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.35,
            child: Image.network(
              'imageUrl',
              fit: BoxFit.cover,
            ),
          ),
          Container(
            color: Colors.grey[300],
            height: MediaQuery.of(context).size.height * 0.5,
            width: MediaQuery.of(context).size.width,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'title',
                            style: TextStyle(
                                fontSize: 25, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'author',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w300),
                          ),
                        ],
                      ),
                      Text(
                        'Price',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w800),
                      )
                    ],
                  ),
                  Text('Detail Tex')
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
