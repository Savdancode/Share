class Strings {
  static var newsUrl =
      Uri.parse("http://assignment-be.jaksmok.com/api/v1/books");
}
